# P4 v6 2차 OCR 캐시 검증 결과

- 대상: Development 10장, 50필드 (GT 49필드)
- Raw Exact Match: 22/49 (44.9%)
- 공백 무시 참고치: 24/49 (공식 지표 아님)
- 검증 방법: 기존 v6 2차 OCR 토큰에 실제 Anchor/ROI 좌표 기반 선택 규칙 재적용, GT와 비교
- 한계: 2차 OCR 신규 실행 아님, 전체 Development/Holdout 미검증

## 실패/상태 분류 (원인 확정 아님)
- ANCHOR_NOT_FOUND: 2건
- GT_PRESENT_IN_OCR_TOKENS_SELECTION_OR_JOIN_ERROR: 1건
- OCR_TEXT_MISMATCH_OR_INCOMPLETE_VALUE_UNDETERMINED: 12건
- RAW_EXACT_MATCH: 22건
- VALUE_SELECTION_FAILED: 11건
- WHITESPACE_ONLY_MISMATCH: 2건

## 전달 자료
- sample_*/field_rois.json: 원본 이미지 좌표 ROI
- sample_*/final_fields.json: 검증된 캐시 재선택 결과와 실패 분류
- summary.csv: GT/예측/일치/실패 분류
- verification_manifest.json: 범위 및 집계
